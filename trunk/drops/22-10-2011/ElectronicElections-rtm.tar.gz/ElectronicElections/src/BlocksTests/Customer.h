/*
 * Customer.h
 *
 *  Created on: Sep 12, 2011
 *      Author: damian
 */

#ifndef CUSTOMER_H_
#define CUSTOMER_H_

struct Customer
{
	char* firstName;
	char* lastName;
	long balance;
};

#endif /* CUSTOMER_H_ */
