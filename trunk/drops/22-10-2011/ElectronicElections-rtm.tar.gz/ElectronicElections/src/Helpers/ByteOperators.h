/*
 * ByteOperators.h
 *
 *  Created on: Sep 18, 2011
 *      Author: damian
 */

#ifndef BYTEOPERATORS_H_
#define BYTEOPERATORS_H_

class ByteOperators
{
public:
	static bool isBitOne(char,char);
	static void setBit(char*, char, char);
};

#endif /* BYTEOPERATORS_H_ */
