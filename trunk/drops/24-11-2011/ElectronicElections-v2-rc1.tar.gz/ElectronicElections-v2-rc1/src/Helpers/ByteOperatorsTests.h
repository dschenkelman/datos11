/*
 * ByteOperatorsTests.h
 *
 *  Created on: Sep 18, 2011
 *      Author: damian
 */

#ifndef BYTEOPERATORSTESTS_H_
#define BYTEOPERATORSTESTS_H_

class ByteOperatorsTests
{
	void printByte(char);
public:
	ByteOperatorsTests();
	void run();
	virtual ~ByteOperatorsTests();
};

#endif /* BYTEOPERATORSTESTS_H_ */
