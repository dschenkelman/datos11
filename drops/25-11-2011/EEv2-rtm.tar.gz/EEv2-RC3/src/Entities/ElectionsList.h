/*
 * ElectionsList.h
 *
 *  Created on: 30/09/2011
 *      Author: lejosdelcielo
 */

#ifndef ELECTIONSLIST_H_
#define ELECTIONSLIST_H_
#include "../VariableBlocks/Constants.h"
#include <cstring>
#include <string>

class ElectionsList {
private:
	char* bytes;
	std::string name;
	char day;
	char month;
	short year;
	std::string charge;
public:
	ElectionsList(std::string name, char day, char month, short year, std::string charge);
	ElectionsList(const ElectionsList& other);
	ElectionsList& operator=(const ElectionsList& other);
	int getSize();
	char* getKey();
	int getKeySize();
	char* getBytes();
	void setBytes(char* bytes);
	virtual ~ElectionsList();
	// getters
	char getDay();
	char getMonth();
	short getYear();
	std::string getName();
	std::string getCharge();
};

#endif /* ELECTIONSLIST_H_ */
