/*
 * VigenereCipherTests.h
 *
 *  Created on: Nov 6, 2011
 *      Author: juanma
 */

#ifndef VIGENERECIPHERTESTS_H_
#define VIGENERECIPHERTESTS_H_

class VigenereCipherTests {
public:
	VigenereCipherTests();
	void run();
	virtual ~VigenereCipherTests();
};

#endif /* VIGENERECIPHERTESTS_H_ */
