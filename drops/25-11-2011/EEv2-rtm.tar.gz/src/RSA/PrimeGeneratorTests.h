/*
 * PrimeGeneratorTests.h
 *
 *  Created on: 06/11/2011
 *      Author: alejandro
 */

#ifndef PRIMEGENERATORTESTS_H_
#define PRIMEGENERATORTESTS_H_

class PrimeGeneratorTests {
public:
	PrimeGeneratorTests();
	virtual ~PrimeGeneratorTests();
};

#endif /* PRIMEGENERATORTESTS_H_ */
