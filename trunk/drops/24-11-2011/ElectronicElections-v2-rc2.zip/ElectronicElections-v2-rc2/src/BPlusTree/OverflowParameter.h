/*
 * OverflowParameter.h
 *
 *  Created on: Oct 1, 2011
 *      Author: damian
 */

#ifndef OVERFLOWPARAMETER_H_
#define OVERFLOWPARAMETER_H_

struct OverflowParameter
{
	int overflowBlock;
	int newBlock;
};

#endif /* OVERFLOWPARAMETER_H_ */
