/*
 * PrimeGeneratorTests.cpp
 *
 *  Created on: 06/11/2011
 *      Author: alejandro
 */

#include "PrimeGeneratorTests.h"

PrimeGeneratorTests::PrimeGeneratorTests() {

}

PrimeGeneratorTests::~PrimeGeneratorTests() {

}

//#include "PrimeGenerator.h"
//#include <iostream>
//using namespace std;
//
//int main() {
//	PrimeGenerator pg(7);
//	int* res = new int[pg.totalGenerated()];
//	pg.getAllPrimes(res);
//	cout << "total"<<pg.totalGenerated()<<endl;
//	for (int i=0;i<pg.totalGenerated();i++) {
//		cout << res[i]<< endl;
//	}
//	return 0;
//}
